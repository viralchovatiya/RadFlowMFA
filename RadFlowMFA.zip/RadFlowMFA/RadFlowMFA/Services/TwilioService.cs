﻿using System;
using Twilio;
using Twilio.Rest.Api.V2010.Account;
using Microsoft.Extensions.Configuration;

namespace RadFlowMFA.Services
{
    public class TwilioService
    {
        private readonly string _accountSid;
        private readonly string _authToken;
        private readonly string _fromNumber;

        // Constructor to initialize TwilioService with configuration settings
        public TwilioService(IConfiguration configuration)
        {
            // Retrieve Twilio credentials and phone number from configuration
            _accountSid = configuration["Twilio:AccountSid"];
            _authToken = configuration["Twilio:AuthToken"];
            _fromNumber = configuration["Twilio:FromNumber"];

            // Initialize Twilio client with the retrieved credentials
            TwilioClient.Init(_accountSid, _authToken);
        }

        // Method to send MFA code to a specified phone number
        public void SendMfaCode(string toPhoneNumber, string code)
        {
            // Create and send a message with the MFA code
            MessageResource.Create(
                body: $"Your MFA Code is: {code}",
                from: new Twilio.Types.PhoneNumber(_fromNumber),
                to: new Twilio.Types.PhoneNumber(toPhoneNumber)
            );
        }
    }
}
