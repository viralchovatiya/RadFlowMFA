﻿using System;
using OtpNet;
using QRCoder;

namespace RadFlowMFA.Services
{
    public class TotpService
    {
        /// <summary>
        /// Generates a random secret key for TOTP.
        /// </summary>
        /// <returns>A Base32 encoded secret key.</returns>
        public string GenerateSecretKey()
        {
            var key = KeyGeneration.GenerateRandomKey(20);
            return Base32Encoding.ToBase32String(key);
        }

        /// <summary>
        /// Generates a QR code for the TOTP setup.
        /// </summary>
        /// <param name="secretKey">The secret key.</param>
        /// <param name="email">The user's email.</param>
        /// <returns>A Base64 encoded string representing the QR code image.</returns>
        public string GenerateQrCode(string secretKey, string email)
        {
            // Generate TOTP URI
            var totpUri = $"otpauth://totp/RadFlowMFA:{email}?secret={secretKey}&issuer=RadFlowMFA";

            // Generate the QR code
            QRCodeGenerator qrGenerator = new QRCodeGenerator();
            var qrCodeData = qrGenerator.CreateQrCode(totpUri, QRCodeGenerator.ECCLevel.Q);
            var qrCode = new QRCode(qrCodeData);

            // Convert the QR code to a Base64 string (e.g., to embed in HTML)
            return Convert.ToBase64String(qrCode.GetGraphic(20));
        }

        /// <summary>
        /// Validates the provided TOTP code against the secret key.
        /// </summary>
        /// <param name="secretKey">The secret key.</param>
        /// <param name="code">The TOTP code to validate.</param>
        /// <returns>True if the code is valid, otherwise false.</returns>
        public bool ValidateTotpCode(string secretKey, string code)
        {
            var totp = new Totp(Base32Encoding.ToBytes(secretKey));
            return totp.VerifyTotp(code, out _);
        }
    }

    public static class Base32Encoding
    {
        private static readonly char[] Base32Alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567".ToCharArray();
        private static readonly string Base32Alphabet2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";

        /// <summary>
        /// Converts a byte array to a Base32 encoded string.
        /// </summary>
        /// <param name="data">The byte array to encode.</param>
        /// <returns>A Base32 encoded string.</returns>
        public static string ToBase32String(byte[] data)
        {
            if (data == null || data.Length == 0)
            {
                return string.Empty;
            }

            int charCount = (int)Math.Ceiling(data.Length / 5d) * 8;
            char[] result = new char[charCount];
            int buffer = 0, next = 0, bitsLeft = 0;

            foreach (byte b in data)
            {
                buffer <<= 8;
                buffer |= b & 0xFF;
                bitsLeft += 8;

                while (bitsLeft >= 5)
                {
                    bitsLeft -= 5;
                    result[next++] = Base32Alphabet[(buffer >> bitsLeft) & 0x1F];
                }
            }

            if (bitsLeft > 0)
            {
                result[next++] = Base32Alphabet[(buffer << (5 - bitsLeft)) & 0x1F];
            }

            return new string(result, 0, next);
        }

        /// <summary>
        /// Converts a Base32 encoded string to a byte array.
        /// </summary>
        /// <param name="base32String">The Base32 encoded string.</param>
        /// <returns>A byte array.</returns>
        /// <exception cref="ArgumentNullException">Thrown when base32String is null or empty.</exception>
        /// <exception cref="FormatException">Thrown when base32String contains invalid characters.</exception>
        public static byte[] ToBytes(string base32String)
        {
            if (string.IsNullOrEmpty(base32String))
            {
                throw new ArgumentNullException(nameof(base32String));
            }

            base32String = base32String.TrimEnd('=').ToUpperInvariant(); // Remove padding

            int byteCount = base32String.Length * 5 / 8; // Convert Base32 string length to byte array length
            byte[] bytes = new byte[byteCount];

            int buffer = 0, bitsLeft = 0, bytesIndex = 0;

            foreach (char c in base32String)
            {
                int value = Base32Alphabet2.IndexOf(c);
                if (value < 0)
                {
                    throw new FormatException($"Invalid Base32 character: {c}");
                }

                buffer = (buffer << 5) | value;
                bitsLeft += 5;

                if (bitsLeft >= 8)
                {
                    bytes[bytesIndex++] = (byte)(buffer >> (bitsLeft - 8));
                    bitsLeft -= 8;
                }
            }
            return bytes;
        }
    }
}
