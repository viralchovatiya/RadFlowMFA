﻿using Microsoft.AspNetCore.Mvc;
using Dapper;
using System.Data;
using RadFlowMFA.Data;

namespace RadFlowMFA.Controllers
{
    public class AdminController : Controller
    {
        private readonly Database _database;

        public AdminController(Database database)
        {
            _database = database;
        }

        /// <summary>
        /// Retrieves the list of users.
        /// </summary>
        /// <returns>A view displaying the list of users.</returns>
        [HttpGet]
        public IActionResult Users()
        {
            using (var connection = _database.CreateConnection())
            {
                var users = connection.Query("SELECT * FROM MFAUsers");
                return View(users);
            }
        }

        /// <summary>
        /// Toggles the MFA setting for a user.
        /// </summary>
        /// <param name="userId">The user identifier.</param>
        /// <param name="enable">if set to <c>true</c> enables MFA, otherwise disables it.</param>
        /// <returns>Redirects to the Users view.</returns>
        [HttpPost]
        public IActionResult ToggleMfa(Guid userId, bool enable)
        {
            using (var connection = _database.CreateConnection())
            {
                connection.Execute("UPDATE MFAUsers SET IsMfaEnabled = @Enable WHERE Id = @UserId",
                    new { Enable = enable, UserId = userId });

                if (!enable)
                {
                    connection.Execute("DELETE FROM MfaSettings WHERE UserId = @UserId", new { UserId = userId });
                }
            }
            return RedirectToAction("Users");
        }

        /// <summary>
        /// Resets the MFA settings for a user.
        /// </summary>
        /// <param name="userId">The user identifier.</param>
        /// <returns>Redirects to the Users view.</returns>
        [HttpPost]
        public IActionResult ResetMfa(Guid userId)
        {
            using (var connection = _database.CreateConnection())
            {
                connection.Execute("DELETE FROM MfaSettings WHERE UserId = @UserId", new { UserId = userId });
                connection.Execute("UPDATE MFAUsers SET IsMfaEnabled = 0, MfaMethod = NULL WHERE Id = @UserId",
                    new { UserId = userId });
            }

            return RedirectToAction("Users");
        }

        /// <summary>
        /// Retrieves the MFA logs.
        /// </summary>
        /// <returns>A view displaying the MFA logs.</returns>
        [HttpGet]
        public IActionResult MfaLogs()
        {
            using (var connection = _database.CreateConnection())
            {
                var logs = connection.Query("SELECT u.Email, a.AttemptTime, a.IsSuccessful FROM MfaAttempts a JOIN Users u ON a.UserId = u.Id ORDER BY a.AttemptTime DESC");
                return View(logs);
            }
        }
    }
}