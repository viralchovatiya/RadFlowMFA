﻿using Microsoft.AspNetCore.Mvc;
using Dapper;
using System.Data;
using RadFlowMFA.Data;
using RadFlowMFA.Services;
using Microsoft.AspNetCore.Http;

namespace RadFlowMFA.Controllers
{
    public class UserMfaController : Controller
    {
        private readonly Database _database;
        private readonly TwilioService _twilioService;
        private readonly TotpService _totpService;
        private readonly EmailService _emailService;

        public UserMfaController(Database database, TwilioService twilioService, TotpService totpService, EmailService emailService)
        {
            _database = database;
            _twilioService = twilioService;
            _totpService = totpService;
            _emailService = emailService;
        }

        /// <summary>
        /// Displays the MFA settings for the logged-in user.
        /// </summary>
        /// <returns>The Index view with user and MFA settings.</returns>
        [HttpGet]
        public IActionResult Index()
        {
            var userId = HttpContext.Session.GetString("UserId");

            if (string.IsNullOrEmpty(userId)) return RedirectToAction("Login", "Account");

            using (var connection = _database.CreateConnection())
            {
                // Retrieve user information from the database
                var user = connection.QueryFirstOrDefault("SELECT * FROM MFAUsers WHERE Id = @UserId", new { UserId = userId });

                // Retrieve MFA settings for the user from the database
                var mfaSetting = connection.QueryFirstOrDefault("SELECT * FROM MfaSettings WHERE UserId = @UserId", new { UserId = userId });

                ViewBag.User = user;
                ViewBag.MfaSetting = mfaSetting;
            }

            return View();
        }

        /// <summary>
        /// Enables MFA for the logged-in user with the specified method.
        /// </summary>
        /// <param name="method">The MFA method to enable (e.g., TOTP, SMS).</param>
        /// <returns>Redirects to the Index action.</returns>
        [HttpPost]
        public IActionResult EnableMfa(string method)
        {
            var userId = HttpContext.Session.GetString("UserId");

            if (string.IsNullOrEmpty(userId)) return RedirectToAction("Login", "Account");

            using (var connection = _database.CreateConnection())
            {
                // Retrieve user email from the database
                var user = connection.QueryFirstOrDefault("SELECT Email FROM MFAUsers WHERE Id = @UserId", new { UserId = userId });

                // Update MFA settings in the database
                connection.Execute("UPDATE MFAUsers SET IsMfaEnabled = 1, MfaMethod = @Method WHERE Id = @UserId",
                    new { Method = method, UserId = userId });

                // Send email notification to the user
                _emailService.SendEmail(user.Email, "MFA Enabled", $"Your Multi-Factor Authentication has been enabled using {method}.");
            }

            TempData["Success"] = "MFA has been enabled successfully!";

            return RedirectToAction("Index");
        }

        /// <summary>
        /// Disables MFA for the logged-in user.
        /// </summary>
        /// <returns>Redirects to the Index action.</returns>
        [HttpPost]
        public IActionResult DisableMfa()
        {
            var userId = HttpContext.Session.GetString("UserId");

            if (string.IsNullOrEmpty(userId)) return RedirectToAction("Login", "Account");

            using (var connection = _database.CreateConnection())
            {
                // Retrieve user email from the database
                var user = connection.QueryFirstOrDefault("SELECT Email FROM MFAUsers WHERE Id = @UserId", new { UserId = userId });

                // Update MFA settings in the database
                connection.Execute("UPDATE MFAUsers SET IsMfaEnabled = 0, MfaMethod = NULL WHERE Id = @UserId",
                    new { UserId = userId });

                // Send email notification to the user
                _emailService.SendEmail(user.Email, "MFA Disabled", "Your Multi-Factor Authentication has been disabled. If this wasn't you, contact support immediately.");
            }

            TempData["Success"] = "MFA has been disabled.";

            return RedirectToAction("Index");
        }
    }
}