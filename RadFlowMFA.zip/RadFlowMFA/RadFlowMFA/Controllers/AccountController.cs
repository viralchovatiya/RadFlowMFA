﻿using Microsoft.AspNetCore.Mvc;
using Dapper;
using System.Data;
using RadFlowMFA.Data;
using RadFlowMFA.Services;
using Org.BouncyCastle.Crypto.Generators;

namespace RadFlowMFA.Controllers
{
    public class AccountController : Controller
    {
        private readonly Database _database;
        private readonly EmailService _emailService;

        /// <summary>
        /// Initializes a new instance of the <see cref="AccountController"/> class.
        /// </summary>
        /// <param name="database">The database.</param>
        /// <param name="emailService">The email service.</param>
        public AccountController(Database database, EmailService emailService)
        {
            _database = database;
            _emailService = emailService;
        }

        /// <summary>
        /// Logins the specified email.
        /// </summary>
        /// <param name="email">The email.</param>
        /// <param name="password">The password.</param>
        /// <returns></returns>
        [HttpPost]
        public IActionResult Login(string email, string password)
        {
            using (var connection = _database.CreateConnection())
            {
                // Query the user by email
                var user = connection.QueryFirstOrDefault("SELECT * FROM Users WHERE Email = @Email", new { Email = email });

                // Verify the password
                if (user != null && BCrypt.Net.BCrypt.Verify(password, user.PasswordHash))
                {
                    // Check if MFA is enabled
                    if (user.IsMfaEnabled)
                    {
                        // Redirect to MFA verification
                        return RedirectToAction("VerifyMfa");
                    }

                    // Redirect to home page
                    return RedirectToAction("Index", "Home");
                }
            }
            // Return to login view if authentication fails
            return View();
        }

        /// <summary>
        /// Verifies the mfa.
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public IActionResult VerifyMfa() => View();

        /// <summary>
        /// Verifies the mfa.
        /// </summary>
        /// <param name="code">The code.</param>
        /// <returns></returns>
        [HttpPost]
        public IActionResult VerifyMfa(string code)
        {
            // Get the user ID from session
            var userId = HttpContext.Session.GetString("UserId");
            if (string.IsNullOrEmpty(userId)) return RedirectToAction("Login");

            using (var connection = _database.CreateConnection())
            {
                // Count recent failed attempts in the last 5 minutes
                var failedAttempts = connection.ExecuteScalar<int>(
                    "SELECT COUNT(*) FROM MfaAttempts WHERE UserId = @UserId AND IsSuccessful = 0 AND AttemptTime > DATEADD(MINUTE, -5, GETDATE())",
                    new { UserId = userId });

                // If there are too many failed attempts, send an alert email
                if (failedAttempts >= 3)
                {
                    var user = connection.QueryFirstOrDefault("SELECT Email FROM MFAUsers WHERE Id = @UserId", new { UserId = userId });

                    _emailService.SendEmail(user.Email, "MFA Alert",
                        "Multiple failed MFA attempts detected. If this wasn't you, consider changing your password or disabling MFA temporarily.");

                    ViewBag.Error = "Too many failed attempts. Try again later.";
                    return View();
                }

                // Get the MFA settings for the user
                var mfaSetting = connection.QueryFirstOrDefault("SELECT * FROM MfaSettings WHERE UserId = @UserId", new { UserId = userId });

                // Validate the MFA code
                bool isValid = ValidateMfaCode(mfaSetting.SecretKey, code);
                connection.Execute("INSERT INTO MfaAttempts (UserId, IsSuccessful) VALUES (@UserId, @Success)",
                    new { UserId = userId, Success = isValid });

                // If the MFA code is valid, redirect to home page
                if (isValid)
                {
                    return RedirectToAction("Index", "Home");
                }
            }

            // Return to MFA verification view if the code is invalid
            ViewBag.Error = "Invalid MFA Code.";
            return View();
        }

        /// <summary>
        /// Validates the mfa code.
        /// </summary>
        /// <param name="secretKey">The secret key.</param>
        /// <param name="code">The code.</param>
        /// <returns></returns>
        private bool ValidateMfaCode(string secretKey, string code)
        {
            // Implement OTP Validation (SMS or TOTP)
            return true;
        }
    }
}
